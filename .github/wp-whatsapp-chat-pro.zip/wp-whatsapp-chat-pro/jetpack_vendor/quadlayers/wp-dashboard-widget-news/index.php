<?php

/**
 * @package     WP Dashboard Widget News
 * @copyright   Copyright (c) 2022, QuadLayers
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU General Public License Version 3
 * @since       1.0.0
 */

require_once 'src/Load.php';
