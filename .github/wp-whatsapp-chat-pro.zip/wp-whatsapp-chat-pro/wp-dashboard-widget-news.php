<?php

if ( class_exists( 'QuadLayers\\WP_Dashboard_Widget_News\\Load' ) ) {
	QuadLayers\WP_Dashboard_Widget_News\Load::instance();
}
