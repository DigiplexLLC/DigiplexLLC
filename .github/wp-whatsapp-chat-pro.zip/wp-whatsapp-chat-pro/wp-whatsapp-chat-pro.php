<?php

/**
 * Plugin Name: Social Chat PRO
 * Description: Send messages directly to your WhatsApp phone number.
 * Plugin URI: https://quadlayers.com/portfolio/whatsapp-chat/
 * Version: 2.7.1
 * Author: QuadLayers
 * Author URI: https://quadlayers.com
 * Copyright: 2022 QuadLayers (https://quadlayers.com)
 * Text Domain: wp-whatsapp-chat-pro
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'QLWAPP_PRO_PLUGIN_NAME', 'Social Chat PRO' );
define( 'QLWAPP_PRO_PLUGIN_VERSION', '2.7.1' );
define( 'QLWAPP_PRO_PLUGIN_FILE', __FILE__ );
define( 'QLWAPP_PRO_PLUGIN_DIR', __DIR__ . DIRECTORY_SEPARATOR );
define( 'QLWAPP_PRO_DEMO_URL', 'https://quadlayers.com/portfolio/whatsapp-chat/?utm_source=qlwapp_admin' );
define( 'QLWAPP_PRO_LICENSES_URL', 'https://quadlayers.com/account/licenses/?utm_source=qlwapp_admin' );
define( 'QLWAPP_PRO_SUPPORT_URL', 'https://quadlayers.com/account/support/?utm_source=qlwapp_admin' );
/**
 * Load composer autoload.
 */
require_once __DIR__ . '/vendor/autoload.php';
/**
 * Load composer packages.
 */
require_once __DIR__ . '/wp-i18n-map.php';
require_once __DIR__ . '/wp-dashboard-widget-news.php';
require_once __DIR__ . '/wp-license-client.php';
require_once __DIR__ . '/wp-notice-plugin-required.php';
require_once __DIR__ . '/wp-plugin-table-links.php';
/**
 * Load plugin.
 */
require_once __DIR__ . '/includes/qlwapp.php';

